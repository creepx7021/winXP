import React from 'react';

import WinXP from 'WinXP';

const App = () => {
  return <WinXP />;
};

export default App;
